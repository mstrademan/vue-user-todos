<template>
	<div class="container">
		<h1>Тестовый проект</h1>
		<p>Данный проект создан для ознакомительных целей с моим кодом. Нажмите на пункт меню <router-link to="/users"><strong>«Users»</strong></router-link></p>
	</div>
</template>

<script>
	export default {
		name: "Home"
	};
</script>