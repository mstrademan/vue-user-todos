module.exports = {
  root: false,
  env: {
    node: false
  }
};
